
document.getElementById('businessQuiz').addEventListener('submit', function (e) {
    e.preventDefault();

    const time = document.getElementById('time').value;
    const skills = document.getElementById('skills').value;
    const investment = document.getElementById('investment').value;

    const results = `
        <p>Based on your inputs, here are three business ideas for you:</p>
        <ol>
            <li>Freelance ${skills} services (minimal investment required).</li>
            <li>Online store selling products with a $${investment} budget.</li>
            <li>Content creation on platforms like YouTube (dedicate ${time} hours/week).</li>
        </ol>
    `;

    document.getElementById('resultsContainer').innerHTML = results;
    document.getElementById('results').classList.remove('hidden');
});
